gdjs.TestLevelCode = {};
gdjs.TestLevelCode.localVariables = [];
gdjs.TestLevelCode.GDSonicObjects1_1final = [];

gdjs.TestLevelCode.GDSonicObjects3_1final = [];

gdjs.TestLevelCode.GDSonicObjects4_1final = [];

gdjs.TestLevelCode.GDSonicObjects5_1final = [];

gdjs.TestLevelCode.GDFloorObjObjects1= [];
gdjs.TestLevelCode.GDFloorObjObjects2= [];
gdjs.TestLevelCode.GDFloorObjObjects3= [];
gdjs.TestLevelCode.GDFloorObjObjects4= [];
gdjs.TestLevelCode.GDFloorObjObjects5= [];
gdjs.TestLevelCode.GDFloorObjObjects6= [];
gdjs.TestLevelCode.GDFloorObjObjects7= [];
gdjs.TestLevelCode.GDFloorObjObjects8= [];
gdjs.TestLevelCode.GDNewText2Objects1= [];
gdjs.TestLevelCode.GDNewText2Objects2= [];
gdjs.TestLevelCode.GDNewText2Objects3= [];
gdjs.TestLevelCode.GDNewText2Objects4= [];
gdjs.TestLevelCode.GDNewText2Objects5= [];
gdjs.TestLevelCode.GDNewText2Objects6= [];
gdjs.TestLevelCode.GDNewText2Objects7= [];
gdjs.TestLevelCode.GDNewText2Objects8= [];
gdjs.TestLevelCode.GDFloorObj2Objects1= [];
gdjs.TestLevelCode.GDFloorObj2Objects2= [];
gdjs.TestLevelCode.GDFloorObj2Objects3= [];
gdjs.TestLevelCode.GDFloorObj2Objects4= [];
gdjs.TestLevelCode.GDFloorObj2Objects5= [];
gdjs.TestLevelCode.GDFloorObj2Objects6= [];
gdjs.TestLevelCode.GDFloorObj2Objects7= [];
gdjs.TestLevelCode.GDFloorObj2Objects8= [];
gdjs.TestLevelCode.GDFloorObj3Objects1= [];
gdjs.TestLevelCode.GDFloorObj3Objects2= [];
gdjs.TestLevelCode.GDFloorObj3Objects3= [];
gdjs.TestLevelCode.GDFloorObj3Objects4= [];
gdjs.TestLevelCode.GDFloorObj3Objects5= [];
gdjs.TestLevelCode.GDFloorObj3Objects6= [];
gdjs.TestLevelCode.GDFloorObj3Objects7= [];
gdjs.TestLevelCode.GDFloorObj3Objects8= [];
gdjs.TestLevelCode.GDLayerSwapperObjects1= [];
gdjs.TestLevelCode.GDLayerSwapperObjects2= [];
gdjs.TestLevelCode.GDLayerSwapperObjects3= [];
gdjs.TestLevelCode.GDLayerSwapperObjects4= [];
gdjs.TestLevelCode.GDLayerSwapperObjects5= [];
gdjs.TestLevelCode.GDLayerSwapperObjects6= [];
gdjs.TestLevelCode.GDLayerSwapperObjects7= [];
gdjs.TestLevelCode.GDLayerSwapperObjects8= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects1= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects2= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects4= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects5= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects6= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects7= [];
gdjs.TestLevelCode.GDShadedDarkJoystickObjects8= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects1= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects4= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects5= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects6= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects7= [];
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects8= [];
gdjs.TestLevelCode.GDSonicObjects1= [];
gdjs.TestLevelCode.GDSonicObjects2= [];
gdjs.TestLevelCode.GDSonicObjects3= [];
gdjs.TestLevelCode.GDSonicObjects4= [];
gdjs.TestLevelCode.GDSonicObjects5= [];
gdjs.TestLevelCode.GDSonicObjects6= [];
gdjs.TestLevelCode.GDSonicObjects7= [];
gdjs.TestLevelCode.GDSonicObjects8= [];


gdjs.TestLevelCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(4)).setNumber(0.046875 * 60);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(5)).setNumber(0.5 * 60);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(6)).setNumber(0.125 * 60);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(7)).setNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(4).getAsNumber());
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(8)).setNumber(6 * 60);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(9)).setNumber(0.21875 * 60);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(14)).setNumber(-(6.5) * 60);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(20)).setNumber(0.125 * 60);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(23)).setNumber(0 * 60);
}
}}

}


};gdjs.TestLevelCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TestLevelCode.GDShadedDarkJoystickObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("YAxis")).setNumber(-(1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TestLevelCode.GDShadedDarkJoystickObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("YAxis")).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TestLevelCode.GDShadedDarkJoystickObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("XAxis")).setNumber(-(1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.TestLevelCode.GDShadedDarkJoystickObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[k] = gdjs.TestLevelCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("XAxis")).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OnScreenControlsButton"), gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3[k] = gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("A")).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OnScreenControlsButton"), gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2[k] = gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11259532);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("APressed")).setNumber(1);
}
}}

}


};gdjs.TestLevelCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects3);
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("XAxis")).setNumber(0);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("YAxis")).setNumber(0);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("A")).setNumber(0);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("APressed")).setNumber(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("HasInput"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects4);
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(10)).setNumber(10);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(11)).setNumber(20);
}
}}

}


{

gdjs.TestLevelCode.GDSonicObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects4);
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)) == "Jump" ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects4);
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)) == "Roll" ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3_1final, gdjs.TestLevelCode.GDSonicObjects3);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(10)).setNumber(8);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(11)).setNumber(15);
}
}}

}


};gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDFloorObj2Objects7Objects = Hashtable.newFrom({"FloorObj2": gdjs.TestLevelCode.GDFloorObj2Objects7});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDFloorObj3Objects7Objects = Hashtable.newFrom({"FloorObj3": gdjs.TestLevelCode.GDFloorObj3Objects7});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDFloorObjObjects7Objects = Hashtable.newFrom({"FloorObj": gdjs.TestLevelCode.GDFloorObjObjects7});
gdjs.TestLevelCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloorObj2"), gdjs.TestLevelCode.GDFloorObj2Objects7);
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects6, gdjs.TestLevelCode.GDSonicObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects7.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects7[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(19)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects7[k] = gdjs.TestLevelCode.GDSonicObjects7[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects7.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDFloorObj2Objects7Objects, gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(2).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0), runtimeScene.getScene().getVariables().getFromIndex(1), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.distanceBetweenPositions(gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()) < gdjs.TestLevelCode.localVariables[1].getFromIndex(4).getAsNumber());
}
}
}
if (isConditionTrue_0) {
{gdjs.TestLevelCode.localVariables[1].getFromIndex(4).setNumber(gdjs.evtTools.common.distanceBetweenPositions(gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()));
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(5).setNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber());
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(6).setNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloorObj3"), gdjs.TestLevelCode.GDFloorObj3Objects7);
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects6, gdjs.TestLevelCode.GDSonicObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects7.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects7[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(19)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects7[k] = gdjs.TestLevelCode.GDSonicObjects7[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects7.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDFloorObj3Objects7Objects, gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(2).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0), runtimeScene.getScene().getVariables().getFromIndex(1), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.distanceBetweenPositions(gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()) < gdjs.TestLevelCode.localVariables[1].getFromIndex(4).getAsNumber());
}
}
}
if (isConditionTrue_0) {
{gdjs.TestLevelCode.localVariables[1].getFromIndex(4).setNumber(gdjs.evtTools.common.distanceBetweenPositions(gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()));
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(5).setNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber());
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(6).setNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloorObj"), gdjs.TestLevelCode.GDFloorObjObjects7);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDFloorObjObjects7Objects, gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(2).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0), runtimeScene.getScene().getVariables().getFromIndex(1), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.distanceBetweenPositions(gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()) < gdjs.TestLevelCode.localVariables[1].getFromIndex(4).getAsNumber());
}
}
if (isConditionTrue_0) {
{gdjs.TestLevelCode.localVariables[1].getFromIndex(4).setNumber(gdjs.evtTools.common.distanceBetweenPositions(gdjs.TestLevelCode.localVariables[1].getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.localVariables[1].getFromIndex(1).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()));
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(5).setNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber());
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(6).setNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects6, gdjs.TestLevelCode.GDSonicObjects7);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects7.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects7[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(25).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 0).getAsNumberOrString()).getChild("Collision")).setBoolean(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[1].getFromIndex(4)) < 1000;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects6, gdjs.TestLevelCode.GDSonicObjects7);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects7.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects7[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(25).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 0).getAsNumberOrString()).getChild("Collision")).setBoolean(true);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects7.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects7[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(25).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 0).getAsNumberOrString()).getChild("X")).setNumber(gdjs.TestLevelCode.localVariables[1].getFromIndex(5).getAsNumber());
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects7.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects7[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(25).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 0).getAsNumberOrString()).getChild("Y")).setNumber(gdjs.TestLevelCode.localVariables[1].getFromIndex(6).getAsNumber());
}
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.TestLevelCode.localVariables[0].getFromIndex(1).add(4);
}}

}


};gdjs.TestLevelCode.eventsList5 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("CentreX", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("CentreY", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("Angle", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("Length", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(1000);
variables._declare("CollisionDistance", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("CollisionX", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("CollisionY", variable);
}
gdjs.TestLevelCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects6);
{gdjs.TestLevelCode.localVariables[1].getFromIndex(0).setNumber((( gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects6[0].getPointX("")) + gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 1).getAsNumber() * Math.cos(gdjs.toRad(((gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects6[0].getVariables()).getFromIndex(17).getAsNumber())));
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(1).setNumber((( gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects6[0].getPointY("")) + gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 1).getAsNumber() * Math.sin(gdjs.toRad(((gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects6[0].getVariables()).getFromIndex(17).getAsNumber())));
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(2).setNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 2).getAsNumber() + ((gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects6[0].getVariables()).getFromIndex(17).getAsNumber());
}{gdjs.TestLevelCode.localVariables[1].getFromIndex(3).setNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getChild(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + 3).getAsNumber());
}
{ //Subevents
gdjs.TestLevelCode.eventsList4(runtimeScene);} //End of subevents
}
gdjs.TestLevelCode.localVariables.pop();

}


};gdjs.TestLevelCode.eventsList6 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "GroundLeft");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), -(((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber()));
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 90);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "GroundRight");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber());
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 90);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber());
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "CeilingLeft");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), -(((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber()));
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), -(90));
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "CeilingRight");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber());
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), -(90));
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber());
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "WallLeft");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 0);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 180);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(12).getAsNumber() - ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(0).getAsNumber() / 60);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "WallRight");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 0);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 0);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(12).getAsNumber() + ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(0).getAsNumber() / 60);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "FloorLeft");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), -(((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber()));
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 90);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber() + 5);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "FloorRight");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber());
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 90);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber() + 5);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "AngleCentre");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 0);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 90);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber() + 24);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "AngleLeft");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), -(((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber()));
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 90);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber() + 24);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects5);
{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), "AngleRight");
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(10).getAsNumber());
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), 90);
}{gdjs.evtTools.variable.valuePush(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), ((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(11).getAsNumber() + 24);
}}

}


{



}


{


const repeatCount5 = gdjs.evtTools.variable.getVariableChildCount(gdjs.TestLevelCode.localVariables[0].getFromIndex(0)) / 4;
for (let repeatIndex5 = 0;repeatIndex5 < repeatCount5;++repeatIndex5) {

let isConditionTrue_0 = false;
if (true)
{

{ //Subevents: 
gdjs.TestLevelCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


};gdjs.TestLevelCode.eventsList7 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variables._declare("SensorsData", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("ArrayIndex", variable);
}
gdjs.TestLevelCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.TestLevelCode.eventsList6(runtimeScene);} //End of subevents
}
gdjs.TestLevelCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(Math.cos(gdjs.toRad(((gdjs.TestLevelCode.GDSonicObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects4[0].getVariables()).getFromIndex(17).getAsNumber()))) >= 0.1);
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(18)).setBoolean(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(Math.cos(gdjs.toRad(((gdjs.TestLevelCode.GDSonicObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects3[0].getVariables()).getFromIndex(17).getAsNumber()))) < 0.1);
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(18)).setBoolean(false);
}
}}

}


};gdjs.TestLevelCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(18), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].setX(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(25).getChild("WallLeft").getChild("X").getAsNumber() + gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(12).getAsNumber());
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(18), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].setY(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("WallLeft").getChild("Y").getAsNumber() - gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(12).getAsNumber());
}
}}

}


};gdjs.TestLevelCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(18), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].setX(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("WallRight").getChild("X").getAsNumber() - gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(12).getAsNumber());
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(18), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].setY(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("WallRight").getChild("Y").getAsNumber() + gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(12).getAsNumber());
}
}}

}


};gdjs.TestLevelCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("WallLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("WallRight").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList11 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).setNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(5).getAsNumber());
}
}}

}


};gdjs.TestLevelCode.eventsList12 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects5, gdjs.TestLevelCode.GDSonicObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects6.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects6[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects6[k] = gdjs.TestLevelCode.GDSonicObjects6[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects6.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects6[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(0)) < gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(8).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects6[k] = gdjs.TestLevelCode.GDSonicObjects6[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects6.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects6 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects6.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects6[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(0)).add(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(4).getAsNumber());
}
}}

}


{



}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).add(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(5).getAsNumber());
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList13 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).setNumber(-(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(5).getAsNumber()));
}
}}

}


};gdjs.TestLevelCode.eventsList14 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) > -(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(8).getAsNumber()) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).sub(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(4).getAsNumber());
}
}}

}


{



}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).sub(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(5).getAsNumber());
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(24).getChild("XAxis")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(25).getChild("WallRight").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("XAxis")) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("WallLeft").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList16 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList17 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) >= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).setNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(5).getAsNumber());
}
}}

}


};gdjs.TestLevelCode.eventsList18 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).setNumber(-(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(5).getAsNumber()));
}
}}

}


};gdjs.TestLevelCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(24).getChild("XAxis")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).add(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(6).getAsNumber());
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("XAxis")) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).sub(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(6).getAsNumber());
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).setNumber(Math.max(0, gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0).getAsNumber() - gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(7).getAsNumber()));
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).setNumber(Math.min(0, gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0).getAsNumber() + gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(7).getAsNumber()));
}
}}

}


};gdjs.TestLevelCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).setNumber(Math.max(0, gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0).getAsNumber() - gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(7).getAsNumber() / 2));
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).setNumber(Math.min(0, gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0).getAsNumber() + gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(7).getAsNumber() / 2));
}
}}

}


};gdjs.TestLevelCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects5, gdjs.TestLevelCode.GDSonicObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects7.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects7[0].getPointY("")))) >= Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects7.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects7[0].getPointY("")))));
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects7 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects7.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects7[i].setY(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() - gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(11).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects7[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects5, gdjs.TestLevelCode.GDSonicObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects6[0].getPointY("")))) < Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects6[0].getPointY("")))));
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects6 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects6.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects6[i].setY(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() - gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(11).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(0)) != 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(1)) != 0;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(0)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects5, gdjs.TestLevelCode.GDSonicObjects6);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects6.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects6[i].setY(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() - gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(11).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(1)) == 0;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].setY(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() - gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(11).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(25).getChild("FloorLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{gdjs.TestLevelCode.localVariables[0].getFromIndex(0).setNumber(((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(25).getChild("FloorLeft").getChild("Y").getAsNumber());
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(25).getChild("FloorRight").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{gdjs.TestLevelCode.localVariables[0].getFromIndex(1).setNumber(((gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects5[0].getVariables()).getFromIndex(25).getChild("FloorRight").getChild("Y").getAsNumber());
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects5_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects6);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects6.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects6[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(25).getChild("FloorLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects6[k] = gdjs.TestLevelCode.GDSonicObjects6[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects6.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects6.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects5_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects6[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects5_1final.push(gdjs.TestLevelCode.GDSonicObjects6[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects6);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects6.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects6[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(25).getChild("FloorRight").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects6[k] = gdjs.TestLevelCode.GDSonicObjects6[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects6.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects6.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects5_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects6[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects5_1final.push(gdjs.TestLevelCode.GDSonicObjects6[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects5_1final, gdjs.TestLevelCode.GDSonicObjects5);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("FloorLeft").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("FloorRight").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(3)).setBoolean(false);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(16).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2).getAsNumber())));
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(1)).setNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(16).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList25 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("LeftColY", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("RightColY", variable);
}
gdjs.TestLevelCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.TestLevelCode.eventsList24(runtimeScene);} //End of subevents
}
gdjs.TestLevelCode.localVariables.pop();

}


};gdjs.TestLevelCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects6[0].getPointX("")))) >= Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects6.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects6[0].getPointX("")))));
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects6 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects6.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects6[i].setX(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(11).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects6[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects5[0].getPointX("")))) < Math.abs(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() - ((( gdjs.TestLevelCode.GDSonicObjects5.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects5[0].getPointX("")))));
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].setX(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() + gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(11).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(0)) != 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(1)) != 0;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList26(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(0)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].setX(gdjs.TestLevelCode.localVariables[0].getFromIndex(1).getAsNumber() + gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(11).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.TestLevelCode.localVariables[0].getFromIndex(1)) == 0;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].setX(gdjs.TestLevelCode.localVariables[0].getFromIndex(0).getAsNumber() + gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(11).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("FloorLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{gdjs.TestLevelCode.localVariables[0].getFromIndex(0).setNumber(((gdjs.TestLevelCode.GDSonicObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects4[0].getVariables()).getFromIndex(25).getChild("FloorLeft").getChild("X").getAsNumber());
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("FloorRight").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{gdjs.TestLevelCode.localVariables[0].getFromIndex(1).setNumber(((gdjs.TestLevelCode.GDSonicObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects4[0].getVariables()).getFromIndex(25).getChild("FloorRight").getChild("X").getAsNumber());
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects5);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(25).getChild("FloorLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects4_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects5[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects4_1final.push(gdjs.TestLevelCode.GDSonicObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects5);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(25).getChild("FloorRight").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects4_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects5[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects4_1final.push(gdjs.TestLevelCode.GDSonicObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4_1final, gdjs.TestLevelCode.GDSonicObjects4);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList27(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("FloorLeft").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("FloorRight").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3)).setBoolean(false);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(16)).setNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0).getAsNumber());
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(16).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(2).getAsNumber())));
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(1)).setNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(16).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(2).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList29 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("LeftColX", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("RightColX", variable);
}
gdjs.TestLevelCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.TestLevelCode.eventsList28(runtimeScene);} //End of subevents
}
gdjs.TestLevelCode.localVariables.pop();

}


};gdjs.TestLevelCode.eventsList30 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)) != "Roll" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList16(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)) == "Roll" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList19(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("XAxis")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)) != "Roll" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)) == "Roll" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList21(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).add(Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2).getAsNumber())) * gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(20).getAsNumber());
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].addForce(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2).getAsNumber())), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2).getAsNumber())), 0);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(18), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList25(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(18), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(16)).setNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0).getAsNumber());
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList32 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)) > gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(8).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).setNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(8).getAsNumber());
}
}}

}


};gdjs.TestLevelCode.eventsList33 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) < -(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(8).getAsNumber()) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).setNumber(-(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(8).getAsNumber()));
}
}}

}


};gdjs.TestLevelCode.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(24).getChild("XAxis")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(0)).add(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(4).getAsNumber() * 2);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList32(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("XAxis")) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).sub(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(4).getAsNumber() * 2);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList35 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(18), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].setY(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(25).getChild("CeilingLeft").getChild("Y").getAsNumber() + gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(11).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(18), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].setX(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("CeilingLeft").getChild("X").getAsNumber() - gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(11).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(18), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].setY(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("CeilingRight").getChild("Y").getAsNumber() + gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(11).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(18), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].setX(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("CeilingRight").getChild("X").getAsNumber() - gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(11).getAsNumber() * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(17).getAsNumber())));
}
}}

}


};gdjs.TestLevelCode.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("CeilingLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList36(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("CeilingRight").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList39 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(21), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList35(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(1)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(1)) > -(4) * 60 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)).sub(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0).getAsNumber() / 0.125 / 256);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(1)).add(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(9).getAsNumber());
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].addForce(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0).getAsNumber(), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(1).getAsNumber(), 0);
}
}}

}


{



}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("CeilingLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("CeilingRight").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3_1final, gdjs.TestLevelCode.GDSonicObjects3);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList40 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(17)).setNumber(0);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects5);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(2)) < 45 ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects4_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects5[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects4_1final.push(gdjs.TestLevelCode.GDSonicObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects5);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(2)) >= 315 ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects4_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects5[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects4_1final.push(gdjs.TestLevelCode.GDSonicObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4_1final, gdjs.TestLevelCode.GDSonicObjects4);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) < 135 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) >= 45 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17)).setNumber(90);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) < 225 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) >= 135 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17)).setNumber(180);
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(2)) < 315 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(2)) >= 225 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(17)).setNumber(270);
}
}}

}


};gdjs.TestLevelCode.eventsList42 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleRight").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)).setNumber(gdjs.evtTools.common.angleBetweenPositions(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleCentre").getChild("X").getAsNumber(), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleCentre").getChild("Y").getAsNumber(), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleRight").getChild("X").getAsNumber(), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleRight").getChild("Y").getAsNumber()));
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)).setNumber(gdjs.evtTools.common.angleBetweenPositions(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleCentre").getChild("X").getAsNumber(), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleCentre").getChild("Y").getAsNumber(), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleLeft").getChild("X").getAsNumber(), gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleLeft").getChild("Y").getAsNumber()) + 180);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)).add(360);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)) >= 360 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(2)).sub(360);
}
}}

}


{


gdjs.TestLevelCode.eventsList41(runtimeScene);
}


};gdjs.TestLevelCode.eventsList43 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("AngleCentre").getChild("Collision"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(3), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


};gdjs.TestLevelCode.eventsList44 = function(runtimeScene) {

{


gdjs.TestLevelCode.eventsList3(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList7(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(1)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("GroundLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("GroundRight").getChild("Collision"), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3_1final, gdjs.TestLevelCode.GDSonicObjects3);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3)).setBoolean(true);
}
}}

}


{


gdjs.TestLevelCode.eventsList10(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList31(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList40(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList43(runtimeScene);
}


};gdjs.TestLevelCode.eventsList45 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects4, gdjs.TestLevelCode.GDSonicObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects5.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects5[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(24).getChild("YAxis")) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects5[k] = gdjs.TestLevelCode.GDSonicObjects5[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects5 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects5.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects5[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects5[i].getVariables().getFromIndex(13)).setString("LookUp");
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("YAxis")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)).setString("Duck");
}
}}

}


};gdjs.TestLevelCode.eventsList46 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(15)) == 1 ) {
        isConditionTrue_2 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleLeft").getChild("Collision"), true, false) ) {
        isConditionTrue_2 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(15)) == -(1) ) {
        isConditionTrue_2 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("AngleRight").getChild("Collision"), true, false) ) {
        isConditionTrue_2 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects4.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects3_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects4[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects3_1final.push(gdjs.TestLevelCode.GDSonicObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3_1final, gdjs.TestLevelCode.GDSonicObjects3);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].getBehavior("Animation").setAnimationName("Balancing1");
}
}}

}


};gdjs.TestLevelCode.eventsList47 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("A")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("CeilingLeft").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(25).getChild("CeilingRight").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)).setString("Jump");
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList45(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("YAxis")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(((gdjs.TestLevelCode.GDSonicObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects4[0].getVariables()).getFromIndex(0).getAsNumber() / 60) >= 0.5);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(13)).setString("Roll");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].setX(gdjs.TestLevelCode.GDSonicObjects4[i].getX() - (5 * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17).getAsNumber()))));
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].setY(gdjs.TestLevelCode.GDSonicObjects4[i].getY() + (5 * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(17).getAsNumber()))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "audio/sfx/spin.wav", false, 100, 1);
}}

}


{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(((gdjs.TestLevelCode.GDSonicObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects4[0].getVariables()).getFromIndex(0).getAsNumber() / 60) >= 4);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("XAxis")) == -(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(15).getAsNumber()) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDSonicObjects4[i].getBehavior("Animation").getAnimationName() == "Skidding") ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].getBehavior("Animation").setAnimationName("Skidding");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "audio/sfx/skid.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getBehavior("Animation").getAnimationName() == "Skidding" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (((gdjs.TestLevelCode.GDSonicObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects4[0].getVariables()).getFromIndex(0).getAsNumber() * ((gdjs.TestLevelCode.GDSonicObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects4[0].getVariables()).getFromIndex(15).getAsNumber() <= 0);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{



}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("AngleCentre").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList46(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects3, gdjs.TestLevelCode.GDSonicObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(24).getChild("XAxis")) != 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects4.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects4[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects4[k] = gdjs.TestLevelCode.GDSonicObjects4[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects4 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].getBehavior("Animation").setAnimationName("Pushing");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects4.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects4[i].getBehavior("Animation").setAnimationSpeedScale(1 / (Math.floor(Math.max(0, 8 - Math.abs(gdjs.TestLevelCode.GDSonicObjects4[i].getVariables().getFromIndex(16).getAsNumber() / 60.0)) * 4) + 1));
}
}{gdjs.TestLevelCode.localVariables[0].getFromIndex(0).setBoolean(true);
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(gdjs.TestLevelCode.localVariables[0].getFromIndex(0), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDSonicObjects3[i].getBehavior("Animation").getAnimationName() == "Balancing1") ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


};gdjs.TestLevelCode.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(((gdjs.TestLevelCode.GDSonicObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects3[0].getVariables()).getFromIndex(16).getAsNumber()) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(((gdjs.TestLevelCode.GDSonicObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects3[0].getVariables()).getFromIndex(16).getAsNumber()) < ((gdjs.TestLevelCode.GDSonicObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects3[0].getVariables()).getFromIndex(8).getAsNumber());
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].getBehavior("Animation").setAnimationName("Walking");
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(((gdjs.TestLevelCode.GDSonicObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects2[0].getVariables()).getFromIndex(16).getAsNumber()) >= ((gdjs.TestLevelCode.GDSonicObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects2[0].getVariables()).getFromIndex(8).getAsNumber());
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationName("Running");
}
}}

}


};gdjs.TestLevelCode.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("XAxis")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(15)).setNumber(1);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("XAxis")) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(15)).setNumber(-(1));
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("Pushing", variable);
}
gdjs.TestLevelCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(((gdjs.TestLevelCode.GDSonicObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects3[0].getVariables()).getFromIndex(16).getAsNumber()) == 0);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList48(runtimeScene);} //End of subevents
}
gdjs.TestLevelCode.localVariables.pop();

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(((gdjs.TestLevelCode.GDSonicObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects2[0].getVariables()).getFromIndex(16).getAsNumber()) > 0);
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationSpeedScale(1 / (Math.floor(Math.max(0, 8 - Math.abs(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(16).getAsNumber() / 60.0))) + 1));
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList49(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList51 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList47(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( !(gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").getAnimationName() == "Skidding") ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList50(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList52 = function(runtimeScene) {

{

/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)).add(-(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(14).getAsNumber()) * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(2).getAsNumber())));
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(1)).setNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(14).getAsNumber() * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(2).getAsNumber())));
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3)).setBoolean(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "audio/sfx/jump.wav", false, 100, 1);
}}

}


};gdjs.TestLevelCode.eventsList53 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(22), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11385396);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(22)).setBoolean(true);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList52(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(13)).setString("Stand");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(21)).setBoolean(false);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].setX(gdjs.TestLevelCode.GDSonicObjects3[i].getX() + (5 * Math.sin(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(17).getAsNumber()))));
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].setY(gdjs.TestLevelCode.GDSonicObjects3[i].getY() - (5 * Math.cos(gdjs.toRad(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(17).getAsNumber()))));
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("A")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(1)) < -(4) * 60 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(1)).setNumber(-(4) * 60);
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(21), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("XAxis")) != 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(15)).setNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("XAxis").getAsNumber());
}
}}

}


};gdjs.TestLevelCode.eventsList54 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("A")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("CeilingLeft").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(25).getChild("CeilingRight").getChild("Collision"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(13)).setString("Jump");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(21)).setBoolean(true);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(13)).setString("Stand");
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(3), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)).setString("Jump");
}
}}

}


};gdjs.TestLevelCode.eventsList55 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("YAxis")) >= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(13)).setString("Stand");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(true);
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("A")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)).setString("Jump");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(true);
}
}}

}


};gdjs.TestLevelCode.eventsList56 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("YAxis")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(13)).setString("Stand");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(true);
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("A")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(23)).setNumber(0);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)).setString("Spindash");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(true);
}
}}

}


};gdjs.TestLevelCode.eventsList57 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11405220);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "audio/sfx/spindash.wav", 1, false, 100, 1);
}{gdjs.evtTools.sound.setSoundOnChannelPitch(runtimeScene, 1, 1);
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("APressed")).setNumber(0);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(23)) >= 8 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(23)).setNumber(8);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(23)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(23)).sub(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(23).getAsNumber() / 0.125 / 256);
}
}}

}


{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(24).getChild("APressed")) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects3.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects3[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects3[i].getVariables().getFromIndex(23)).add(2);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "audio/sfx/spindash.wav", 1, false, 100, 1);
}{gdjs.evtTools.sound.setSoundOnChannelPitch(runtimeScene, 1, 1 + ((gdjs.TestLevelCode.GDSonicObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TestLevelCode.GDSonicObjects3[0].getVariables()).getFromIndex(23).getAsNumber() / 16);
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("YAxis")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)).setString("Roll");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(true);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(0)).setNumber((8 + (Math.floor(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(23).getAsNumber()) / 2)) * 60 * gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(15).getAsNumber());
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "audio/sfx/spindash_release.wav", false, 100, 1);
}}

}


};gdjs.TestLevelCode.eventsList58 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationSpeedScale(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)) == "Stand" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList51(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)) == "Jump" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationName("Jumping");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationSpeedScale(1 / (Math.floor(Math.max(0, 4 - Math.abs(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(16).getAsNumber() / 60.0))) + 1));
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList53(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(22), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)) != "Jump" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(22)).setBoolean(false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)) == "Roll" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationName("Jumping");
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList54(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)) == "LookUp" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationName("LookUp");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(false);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList55(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)) == "Duck" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationName("Duck");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(false);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList56(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableString(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(13)) == "Spindash" ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").setAnimationName("Jumping");
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(24).getChild("AllowDirectionalMovement")).setBoolean(false);
}
}
{ //Subevents
gdjs.TestLevelCode.eventsList57(runtimeScene);} //End of subevents
}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(15)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(15)) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].setAngle(0);
}
}}

}


{

gdjs.TestLevelCode.GDSonicObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.TestLevelCode.GDSonicObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").getAnimationName() == "Walking" ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects2.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects1_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects2[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects1_1final.push(gdjs.TestLevelCode.GDSonicObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getBehavior("Animation").getAnimationName() == "Running" ) {
        isConditionTrue_1 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TestLevelCode.GDSonicObjects2.length; j < jLen ; ++j) {
        if ( gdjs.TestLevelCode.GDSonicObjects1_1final.indexOf(gdjs.TestLevelCode.GDSonicObjects2[j]) === -1 )
            gdjs.TestLevelCode.GDSonicObjects1_1final.push(gdjs.TestLevelCode.GDSonicObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects1_1final, gdjs.TestLevelCode.GDSonicObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects1[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects1[i].getVariables().getFromIndex(2)) < 330 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects1[k] = gdjs.TestLevelCode.GDSonicObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects1[i].getVariableNumber(gdjs.TestLevelCode.GDSonicObjects1[i].getVariables().getFromIndex(2)) > 30 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects1[k] = gdjs.TestLevelCode.GDSonicObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects1[i].setAngle(Math.round(gdjs.TestLevelCode.GDSonicObjects1[i].getVariables().getFromIndex(2).getAsNumber() / 45.0) * 45.0);
}
}}

}


};gdjs.TestLevelCode.eventsList59 = function(runtimeScene) {

{


gdjs.TestLevelCode.eventsList0(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList2(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList44(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList58(runtimeScene);
}


};gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDSonicObjects1Objects = Hashtable.newFrom({"Sonic": gdjs.TestLevelCode.GDSonicObjects1});
gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDLayerSwapperObjects1Objects = Hashtable.newFrom({"LayerSwapper": gdjs.TestLevelCode.GDLayerSwapperObjects1});
gdjs.TestLevelCode.eventsList60 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects1, gdjs.TestLevelCode.GDSonicObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].isTotalForceAngleAround(0, 45) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects2[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(19)).setNumber(1);
}
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects1[i].isTotalForceAngleAround(180, 45) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects1[k] = gdjs.TestLevelCode.GDSonicObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects1 */
{for(var i = 0, len = gdjs.TestLevelCode.GDSonicObjects1.length ;i < len;++i) {
    gdjs.TestLevelCode.GDSonicObjects1[i].returnVariable(gdjs.TestLevelCode.GDSonicObjects1[i].getVariables().getFromIndex(19)).setNumber(0);
}
}}

}


};gdjs.TestLevelCode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LayerSwapper"), gdjs.TestLevelCode.GDLayerSwapperObjects2);
{for(var i = 0, len = gdjs.TestLevelCode.GDLayerSwapperObjects2.length ;i < len;++i) {
    gdjs.TestLevelCode.GDLayerSwapperObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LayerSwapper"), gdjs.TestLevelCode.GDLayerSwapperObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDSonicObjects1Objects, gdjs.TestLevelCode.mapOfGDgdjs_9546TestLevelCode_9546GDLayerSwapperObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList60(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList62 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects2, gdjs.TestLevelCode.GDSonicObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects3.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects3[i].getY() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - 32 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects3[k] = gdjs.TestLevelCode.GDSonicObjects3[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects3 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.TestLevelCode.GDSonicObjects3.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects3[0].getPointY("")) + 32, "", 0);
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getY() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 32 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.TestLevelCode.GDSonicObjects2.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects2[0].getPointY("")) - 32, "", 0);
}}

}


};gdjs.TestLevelCode.eventsList63 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TestLevelCode.GDSonicObjects1, gdjs.TestLevelCode.GDSonicObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getY() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, Math.min(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 8 * 60 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), (( gdjs.TestLevelCode.GDSonicObjects2.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects2[0].getPointY(""))), "", 0);
}}

}


{

/* Reuse gdjs.TestLevelCode.GDSonicObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects1[i].getY() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects1[k] = gdjs.TestLevelCode.GDSonicObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects1 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, Math.max(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - 8 * 60 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), (( gdjs.TestLevelCode.GDSonicObjects1.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects1[0].getPointY(""))), "", 0);
}}

}


};gdjs.TestLevelCode.eventsList64 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - 16 ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.TestLevelCode.GDSonicObjects2.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects2[0].getPointX("")) + 16, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getX() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TestLevelCode.GDSonicObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.TestLevelCode.GDSonicObjects2.length === 0 ) ? 0 :gdjs.TestLevelCode.GDSonicObjects2[0].getPointX("")), "", 0);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects2.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects2[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects2[i].getVariables().getFromIndex(3), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects2[k] = gdjs.TestLevelCode.GDSonicObjects2[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList62(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sonic"), gdjs.TestLevelCode.GDSonicObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TestLevelCode.GDSonicObjects1.length;i<l;++i) {
    if ( gdjs.TestLevelCode.GDSonicObjects1[i].getVariableBoolean(gdjs.TestLevelCode.GDSonicObjects1[i].getVariables().getFromIndex(3), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.TestLevelCode.GDSonicObjects1[k] = gdjs.TestLevelCode.GDSonicObjects1[i];
        ++k;
    }
}
gdjs.TestLevelCode.GDSonicObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TestLevelCode.eventsList63(runtimeScene);} //End of subevents
}

}


};gdjs.TestLevelCode.eventsList65 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SoundManagement__LevelMusicRequested.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "audio/music/testlevel.ogg", true, 100, 1);
}}

}


};gdjs.TestLevelCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}{gdjs.evtsExt__SoundManagement__RequestLevelMusic.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


gdjs.TestLevelCode.eventsList59(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList61(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList64(runtimeScene);
}


{


gdjs.TestLevelCode.eventsList65(runtimeScene);
}


};

gdjs.TestLevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TestLevelCode.GDFloorObjObjects1.length = 0;
gdjs.TestLevelCode.GDFloorObjObjects2.length = 0;
gdjs.TestLevelCode.GDFloorObjObjects3.length = 0;
gdjs.TestLevelCode.GDFloorObjObjects4.length = 0;
gdjs.TestLevelCode.GDFloorObjObjects5.length = 0;
gdjs.TestLevelCode.GDFloorObjObjects6.length = 0;
gdjs.TestLevelCode.GDFloorObjObjects7.length = 0;
gdjs.TestLevelCode.GDFloorObjObjects8.length = 0;
gdjs.TestLevelCode.GDNewText2Objects1.length = 0;
gdjs.TestLevelCode.GDNewText2Objects2.length = 0;
gdjs.TestLevelCode.GDNewText2Objects3.length = 0;
gdjs.TestLevelCode.GDNewText2Objects4.length = 0;
gdjs.TestLevelCode.GDNewText2Objects5.length = 0;
gdjs.TestLevelCode.GDNewText2Objects6.length = 0;
gdjs.TestLevelCode.GDNewText2Objects7.length = 0;
gdjs.TestLevelCode.GDNewText2Objects8.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects1.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects2.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects3.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects4.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects5.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects6.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects7.length = 0;
gdjs.TestLevelCode.GDFloorObj2Objects8.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects1.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects2.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects3.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects4.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects5.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects6.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects7.length = 0;
gdjs.TestLevelCode.GDFloorObj3Objects8.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects1.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects2.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects3.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects4.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects5.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects6.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects7.length = 0;
gdjs.TestLevelCode.GDLayerSwapperObjects8.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects4.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects5.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects6.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects7.length = 0;
gdjs.TestLevelCode.GDShadedDarkJoystickObjects8.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects1.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects2.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects3.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects4.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects5.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects6.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects7.length = 0;
gdjs.TestLevelCode.GDOnScreenControlsButtonObjects8.length = 0;
gdjs.TestLevelCode.GDSonicObjects1.length = 0;
gdjs.TestLevelCode.GDSonicObjects2.length = 0;
gdjs.TestLevelCode.GDSonicObjects3.length = 0;
gdjs.TestLevelCode.GDSonicObjects4.length = 0;
gdjs.TestLevelCode.GDSonicObjects5.length = 0;
gdjs.TestLevelCode.GDSonicObjects6.length = 0;
gdjs.TestLevelCode.GDSonicObjects7.length = 0;
gdjs.TestLevelCode.GDSonicObjects8.length = 0;

gdjs.TestLevelCode.eventsList66(runtimeScene);

return;

}

gdjs['TestLevelCode'] = gdjs.TestLevelCode;
